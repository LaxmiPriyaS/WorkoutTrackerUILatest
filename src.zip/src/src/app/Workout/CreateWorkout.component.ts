import { Component, OnInit } from '@angular/core';
import { SharedService } from "./../shared.service";

@Component({
  selector: 'app-createworkout',
  templateUrl: './CreateWorkout.component.html',
  styles: [] ,
  providers:[SharedService] 
})
export class CreateWorkoutComponent implements OnInit {
	name:string;
  
	workoutId:string;
	workoutPageType:string;
	workoutPageAction:string;	
	isEditWorkout:boolean;
	errorMsg:string;
	
 addWorkoutCbpm: number=0.1 ;
 
 addWorkoutTitle: string = "";
 addWorkoutNote: string = "";
 addWorkoutCategory: string = "";
 
 constructor(private _sharedService: SharedService) {} 
  

  ngOnInit() {
  }
      //call service to save new Category
    createWorkout(): void {	
	    if(this.addWorkoutTitle==null || this.addWorkoutTitle==''){
			this.errorMsg="Workout Title is mandatory";
			return;
		}	
	    if(this.addWorkoutCbpm <= 0){
			this.errorMsg="Calories Burnt must be a positive value above zero.";
			return;
		}	
	    if(this.addWorkoutCategory==null || this.addWorkoutCategory==''){
			this.errorMsg="Category title is required.";
			return;		
		}	
  }
 incrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 + 0.1*10) / 10;  
            }
   decrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 - 0.1*10) / 10; 
            }
  CreateWorkoutFunc() { 
    this._sharedService.AddWorkout(this); 

  }
}

