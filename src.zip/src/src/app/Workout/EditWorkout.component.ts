import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from "./../shared.service";


@Component({
  selector: 'app-editworkout',
  templateUrl: './EditWorkout.component.html',
  styles: [],
  providers:[SharedService] 
})
export class EditWorkoutComponent implements OnInit {
  
  
  editWorkoutTitle: string = "";
editWorkoutNote: string = "";
selectCategory: string = "";
editCategory:string = "";
errorMsg:string;
constructor(private router: Router,private _sharedService: SharedService) { }

  ngOnInit() {
  }
  editWorkout(): void {	
	    if(this.editWorkoutTitle==null || this.editWorkoutTitle==''){
			this.errorMsg="Workout Title is mandatory";
			return;
		}
	    if(this.editCategory==null || this.editCategory==''){
			this.errorMsg="Category title is required.";
			return;		
		}	
  }
cancelEditWorkout()
{
	this.router.navigate(['/viewWorkout']); 
}
CreateWorkoutFunc() {  
  this._sharedService.EditWorkout(this);
    
 }
}