import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from "./../shared.service";

@Component({
  selector: 'app-endworkout',
  templateUrl: './EndWorkout.component.html',
  styles: [],
  providers:[SharedService] 
})
export class EndWorkoutComponent implements OnInit {
	endDate : Date =new Date();
	endTime : Date =new Date();
	endWorkoutTitle:string="";
errorMsg:string;
constructor(private router: Router) { }


  ngOnInit() {
  }
      endWorkout(): void {	
	    if(this.endWorkoutTitle==null || this.endWorkoutTitle==''){
			this.errorMsg="Workout Title is mandatory";
			return;
		}		
  }
	cancelEditWorkout()
	{
		this.router.navigate(['/viewWorkout']); 
	}
 
}