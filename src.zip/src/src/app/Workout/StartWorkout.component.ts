import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-startworkout,date-pipe',
  templateUrl: './StartWorkout.component.html',
  styles: [] 
})

export class StartWorkoutComponent implements OnInit {
	startDate : Date=new Date();
	startTime : Date=new Date();
	startWorkoutTitle:string = "";
errorMsg:string;
 
 constructor(private router: Router) { }

  ngOnInit() {
	  
  }
  startWorkout(){
	if(this.startWorkoutTitle==null || this.startWorkoutTitle==''){
			this.errorMsg="Workout Title is mandatory";
			return;
		}	  
  }

 cancelStartWorkout()
{
	this.router.navigate(['/viewWorkout']); 
}
}

	
